const catalogSchema = new mongoose.Schema
({
code: String,
name: String,
description: String,
price: Number,
quantity: Number,
image: String
});

for(let i=0;i<data.length;i++)
{
    let catalog="";
    catalog+=`
    <div style="border:solid green 1px;background:#FFFFFF;float:left">
    <div class="title">${data[i].name}</div>
    <span class="left"><a href="panasonic.html"><img src="images/${data[i].image}" style="width:200px;" alt="example graphic" /></a></span>
    <p class="size">
    ${data[i].description}
      <a href="panasonic.html">More...</a><br />
    <span style="float:right;text-align:left;padding:.5em;">
    <a href="#">Add to Cart</a>&nbsp;&nbsp;<a href="#">Goto Cart</a>
    </span>
    </p>
    </div>               
    <p style="clear:both"></p>
    `;
    res.render ( "products.ejs",{catalog:catalog,message:""});
}